import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;

public class AsentamientosPorCodigoPostalGUI extends JFrame {
    private JTextArea resultTextArea;

    public AsentamientosPorCodigoPostalGUI() {
        setTitle("Asentamientos por Código Postal");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel contentPanel = new JPanel(new BorderLayout());

        resultTextArea = new JTextArea();
        resultTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(resultTextArea);

        JButton analyzeButton = new JButton("Analizar");
        analyzeButton.setFont(new Font("Arial", Font.BOLD, 16));
        analyzeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                analyzeAndDisplayResults();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(analyzeButton);

        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        getContentPane().add(contentPanel);
    }

    private void analyzeAndDisplayResults() {
        final String fileName = "codigos_postales_hmo.csv"; // Corregir la extensión del archivo
        try {
            // Obtén la ruta del archivo CSV dentro del proyecto
            Path csvFilePath = Paths.get(getClass().getResource(fileName).toURI());
            Map<String, Integer> codigosPostales = analyzeCSVFile(csvFilePath.toString());
            displayResults(codigosPostales);
        } catch (Exception e) {
            e.printStackTrace();
            resultTextArea.setText("Error al analizar el archivo.");
        }
    }

    private Map<String, Integer> analyzeCSVFile(String csvFilePath) {
        String line;
        String csvSplitBy = ",";
        Map<String, Integer> codigosPostales = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            while ((line = br.readLine()) != null) {
                String[] data = line.split(csvSplitBy);
                if (data.length >= 2) {
                    String codigoPostal = data[1].trim();
                    codigosPostales.put(codigoPostal, codigosPostales.getOrDefault(codigoPostal, 0) + 1);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return codigosPostales;
    }

    private void displayResults(Map<String, Integer> codigosPostales) {
        resultTextArea.setText("Códigos postales y cantidad de asentamientos:\n");
        for (Map.Entry<String, Integer> entry : codigosPostales.entrySet()) {
            resultTextArea.append("Código Postal: " + entry.getKey() + " - Cantidad de Asentamientos: " + entry.getValue() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AsentamientosPorCodigoPostalGUI().setVisible(true);
            }
        });
    }
}
